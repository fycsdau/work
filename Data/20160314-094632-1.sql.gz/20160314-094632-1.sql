-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : liulianghulian
-- 
-- Part : #1
-- Date : 2016-03-14 09:46:32
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `goods`
-- -----------------------------
DROP TABLE IF EXISTS `goods`;
;


-- -----------------------------
-- Table structure for `info`
-- -----------------------------
DROP TABLE IF EXISTS `info`;
;


-- -----------------------------
-- Table structure for `llhl_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `llhl_auth_group`;
;

-- -----------------------------
-- Records of `llhl_auth_group`
-- -----------------------------
INSERT INTO `llhl_auth_group` VALUES ('33', '1', '管理员', '0', '0', '1', '1', '');
INSERT INTO `llhl_auth_group` VALUES ('34', '1', '订单查看', '0', '0', '2', '1', '1,2,3');

-- -----------------------------
-- Table structure for `llhl_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `llhl_auth_group_access`;
;

-- -----------------------------
-- Records of `llhl_auth_group_access`
-- -----------------------------
INSERT INTO `llhl_auth_group_access` VALUES ('0', '0');
INSERT INTO `llhl_auth_group_access` VALUES ('0', '0');
INSERT INTO `llhl_auth_group_access` VALUES ('0', '0');
INSERT INTO `llhl_auth_group_access` VALUES ('11', '34');
INSERT INTO `llhl_auth_group_access` VALUES ('1', '33');

-- -----------------------------
-- Table structure for `llhl_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `llhl_auth_rule`;
;

-- -----------------------------
-- Records of `llhl_auth_rule`
-- -----------------------------
INSERT INTO `llhl_auth_rule` VALUES ('1', '0', '0', 'home/fans', '会员管理', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('2', '0', '0', 'home/order/index', '订单管理', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('3', '0', '0', 'home/goods/index', '流量套餐管理', '1', '1', '', '3');
INSERT INTO `llhl_auth_rule` VALUES ('4', '0', '0', 'home/wechat/index', '微信平台管理', '1', '1', '', '4');
INSERT INTO `llhl_auth_rule` VALUES ('5', '0', '0', 'home/user', '后台用户管理', '1', '1', '', '5');
INSERT INTO `llhl_auth_rule` VALUES ('6', '0', '0', 'home/log/index', '日志管理', '1', '1', '', '6');
INSERT INTO `llhl_auth_rule` VALUES ('7', '0', '0', 'home/system/index', '系统管理', '1', '1', '', '7');
INSERT INTO `llhl_auth_rule` VALUES ('8', '1', '1', 'home/fans/index', '会员列表', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('9', '1', '1', 'home/moneyoffer/index', '提现申请管理', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('10', '1', '1', 'home/moneyoffer/set', '提现设置', '1', '1', '', '3');
INSERT INTO `llhl_auth_rule` VALUES ('11', '1', '2', 'home/order/index', '订单列表', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('12', '1', '2', 'home/affiliate/index', '分成管理', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('13', '1', '4', 'home/wechat/index', '微信接口参数设置', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('14', '1', '4', 'home/wechat/subscribe', '用户关注回复', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('15', '1', '4', 'home/wechat/menu', '自定义菜单', '1', '1', '', '3');
INSERT INTO `llhl_auth_rule` VALUES ('16', '1', '4', 'home/wechat/keyword', '关键字回复', '1', '1', '', '3');
INSERT INTO `llhl_auth_rule` VALUES ('17', '1', '4', 'home/wechat/pay', '微信支付参数', '1', '1', '', '4');
INSERT INTO `llhl_auth_rule` VALUES ('18', '1', '5', 'home/user/index', '用户列表', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('19', '1', '5', 'home/dep/index', '角色管理', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('20', '1', '6', 'home/log/index', '系统操作日志', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('21', '1', '6', 'home/sms/log', '短信发送日志', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('22', '1', '7', 'home/sms/config', '短信接口设置', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('23', '1', '7', 'home/database', '数据库管理', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('24', '1', '7', 'home/system/index', '系统设置', '1', '1', '', '3');
INSERT INTO `llhl_auth_rule` VALUES ('25', '2', '8', 'home/fans/edit', '修改会员信息', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('26', '2', '8', 'home/fans/delete', '删除会员', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('27', '2', '18', 'home/user/add', '添加用户', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('28', '2', '18', 'home/user/edit', '修改用户', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('29', '2', '18', 'home/user/delete', '删除用户', '1', '1', '', '3');
INSERT INTO `llhl_auth_rule` VALUES ('30', '2', '19', 'home/dep/add', '添加角色', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('31', '2', '19', 'home/dep/edit', '修改角色', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('32', '2', '19', 'home/dep/delete', '删除角色', '1', '1', '', '3');
INSERT INTO `llhl_auth_rule` VALUES ('33', '2', '20', 'home/log/delete', '删除', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('34', '2', '23', 'home/database/bakup', '数据库备份', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('35', '2', '23', 'home/database/index', '数据库优化', '1', '1', '', '0');
INSERT INTO `llhl_auth_rule` VALUES ('36', '2', '24', 'home/config/index', '数据字典', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('37', '2', '24', 'home/menu/index', '菜单管理', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('38', '2', '24', 'home/rule/index', '功能列表', '1', '1', '', '3');
INSERT INTO `llhl_auth_rule` VALUES ('39', '1', '3', 'home/goods/add', '添加套餐', '1', '1', '', '1');
INSERT INTO `llhl_auth_rule` VALUES ('40', '1', '3', 'home/goods/edit', '修改套餐', '1', '1', '', '2');
INSERT INTO `llhl_auth_rule` VALUES ('41', '1', '3', 'home/goods/delete', '删除套餐', '1', '1', '', '3');

-- -----------------------------
-- Table structure for `llhl_config`
-- -----------------------------
DROP TABLE IF EXISTS `llhl_config`;
;

-- -----------------------------
-- Records of `llhl_config`
-- -----------------------------
INSERT INTO `llhl_config` VALUES ('1', '系统', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '', '主要用于数据解析和页面表单的生成', '2015-02-01 14:39:41', '2015-02-25 10:44:48', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '0');
INSERT INTO `llhl_config` VALUES ('2', '基础', 'PERPAGE', '0', '管理后台 - 每页条数', '', '列表分页条数', '2015-02-01 14:49:47', '2016-01-17 10:58:57', '1', '15', '0');
INSERT INTO `llhl_config` VALUES ('3', '基础', 'SEARCHKEY', '3', '参与搜索的字段名', '', '', '2015-02-01 14:56:03', '2016-01-20 17:52:39', '1', '1:name\r\n2:title\r\n3:username\r\n4:value\r\n5:tel\r\n6:phone\r\n7:type\r\n8:user_phone\r\n9:user_city\r\n10:sex\r\n11:user_auth', '0');
INSERT INTO `llhl_config` VALUES ('4', '系统', 'DATA_CACHE_TIME', '0', '数据缓存时间', '', '数据缓存有效期 0表示永久缓存', '2015-02-01 15:05:20', '2015-02-25 10:44:23', '1', '14400', '0');
INSERT INTO `llhl_config` VALUES ('5', '系统', 'SESSION_PREFIXX', '1', 'session 前缀', '', '', '2015-02-01 15:07:09', '2016-03-11 10:59:00', '1', 'llhl', '0');
INSERT INTO `llhl_config` VALUES ('6', '系统', 'WEB_SITE_TITLE', '2', '系统名称', '', '', '2015-02-01 15:17:46', '2016-03-11 10:57:20', '1', '流量互联 - 联合百万用户为你的流量省钱', '0');
INSERT INTO `llhl_config` VALUES ('11', '模型', 'MODEL_B_SHOW', '3', '字段模型表单显示', '', '', '2015-02-01 22:12:54', '2015-02-25 10:43:02', '1', '0:不显示\r\n1:都显示\r\n2:新增显示\r\n3:编辑显示', '0');
INSERT INTO `llhl_config` VALUES ('7', '系统', 'DATA_BACKUP_PATH', '1', '数据库备份路径', '', '', '2015-02-01 15:55:43', '2015-02-25 10:43:53', '1', 'data', '0');
INSERT INTO `llhl_config` VALUES ('8', '系统', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '2015-02-01 15:56:41', '2015-02-25 10:44:00', '1', '20971520', '0');
INSERT INTO `llhl_config` VALUES ('9', '系统', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '2015-02-01 15:57:49', '2015-02-25 10:43:30', '1', '1', '0');
INSERT INTO `llhl_config` VALUES ('10', '系统', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '2015-02-01 15:58:48', '2015-02-25 10:43:25', '1', '9', '0');
INSERT INTO `llhl_config` VALUES ('12', '模型', 'MODEL_L_SHOW', '3', '字段模型列表显示', '', '', '2015-02-02 14:55:31', '2015-02-25 10:42:53', '1', '0:不显示\r\n1:显示', '0');
INSERT INTO `llhl_config` VALUES ('13', '模型', 'MODEL_B_ATTR', '3', '数据模型中表单属性', '', '', '2015-02-02 15:46:08', '2015-02-28 11:40:06', '1', '0:文本框\r\n1:文本域\r\n2:密码框\r\n3:日期框\r\n4:编辑器\r\n5:微调器\r\n6:单选框\r\n7:多选框\r\n8:下拉框\r\n9:查找带回\r\n10:上传附件\r\n11:日期时间框', '0');
INSERT INTO `llhl_config` VALUES ('14', '模型', 'MODEL_B_ISMUST', '3', '数据模型中是否必填', '', '', '2015-02-02 16:05:26', '2015-02-28 11:37:48', '1', '0:非必填\r\n1:必填\r\n2:必填日期\r\n3:必填手机号码\r\n4:必填EMAIL\r\n5:必填字母\r\n6:必填身份证号码\r\n7:必填中文\r\n8:必填数字\r\n9:必填日期时间', '0');
INSERT INTO `llhl_config` VALUES ('15', '模型', 'MODEL_B_ISSORT', '3', '数据模型中的字段是否参与排序', '', '', '2015-02-02 19:53:07', '2015-02-25 10:42:27', '1', '0:不参与\r\n1:参与', '0');
INSERT INTO `llhl_config` VALUES ('16', '基础', 'BASE_SEX', '3', '性别', '', '', '2015-02-02 21:21:58', '2015-02-25 10:28:07', '1', '0:男\r\n1:女', '0');
INSERT INTO `llhl_config` VALUES ('18', '基础', 'CONFIG_CLASS', '3', '配置分类', '', '', '2015-02-25 10:22:21', '2016-01-06 20:51:38', '1', '0:系统\r\n1:基础\r\n2:模型', '0');
INSERT INTO `llhl_config` VALUES ('43', '基础', 'USER_PERPAGE', '0', '用户前台 - 每页条数', '', '', '2016-01-17 11:05:24', '2016-01-17 11:26:32', '1', '5', '1');

-- -----------------------------
-- Table structure for `llhl_log`
-- -----------------------------
DROP TABLE IF EXISTS `llhl_log`;
;

-- -----------------------------
-- Records of `llhl_log`
-- -----------------------------
INSERT INTO `llhl_log` VALUES ('1', '2016-03-11 09:57:45', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('2', '2016-03-11 09:57:58', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('3', '2016-03-11 09:59:11', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('4', '2016-03-11 09:59:13', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('5', '2016-03-11 09:59:16', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('6', '2016-03-11 09:59:47', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('7', '2016-03-11 09:59:54', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('8', '2016-03-11 10:00:53', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('9', '2016-03-11 10:01:39', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('10', '2016-03-11 10:08:55', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('11', '2016-03-11 10:09:22', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('12', '2016-03-11 10:13:45', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('13', '2016-03-11 10:13:54', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('14', '2016-03-11 10:14:23', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('15', '2016-03-11 10:17:59', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('16', '2016-03-11 10:18:10', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('17', '2016-03-11 10:22:03', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('18', '2016-03-11 10:22:27', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('19', '2016-03-11 10:22:35', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('20', '2016-03-11 10:23:11', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('21', '2016-03-11 10:29:29', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('22', '2016-03-11 10:31:27', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('23', '2016-03-11 10:33:58', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('24', '2016-03-11 10:35:14', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('25', '2016-03-11 10:39:00', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('26', '2016-03-11 10:42:38', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('27', '2016-03-11 10:51:15', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('28', '2016-03-11 10:55:55', 'admin', 'Config 删除 45', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Config/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('29', '2016-03-11 10:56:08', 'admin', 'Config 删除 44', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Config/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('30', '2016-03-11 10:56:19', 'admin', 'Config 删除 41', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Config/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('31', '2016-03-11 10:56:26', 'admin', 'Config 删除 40', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Config/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('32', '2016-03-11 10:57:20', 'admin', 'config 编辑 6', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Config/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('33', '2016-03-11 10:58:17', 'admin', 'Config 删除 38', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Config/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('34', '2016-03-11 10:58:23', 'admin', 'Config 删除 39', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Config/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('35', '2016-03-11 10:59:00', 'admin', 'config 编辑 5', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Config/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('36', '2016-03-11 11:01:42', 'admin', 'Menu锁定77', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/status.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('37', '2016-03-11 11:01:47', 'admin', 'Menu 删除 77', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('38', '2016-03-11 11:01:50', 'admin', 'Menu 删除 78', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('39', '2016-03-11 11:01:53', 'admin', 'Menu 删除 79', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('40', '2016-03-11 11:01:55', 'admin', 'Menu 删除 80', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('41', '2016-03-11 11:01:57', 'admin', 'Menu 删除 106', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('42', '2016-03-11 11:01:59', 'admin', 'Menu 删除 105', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('43', '2016-03-11 11:02:02', 'admin', 'Menu 删除 1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('44', '2016-03-11 11:02:21', 'admin', 'menu 编辑 81', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('45', '2016-03-11 11:02:36', 'admin', 'menu 编辑 82', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('46', '2016-03-11 11:04:15', 'admin', 'menu 编辑 83', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('47', '2016-03-11 11:06:50', 'admin', 'menu 新增 107', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('48', '2016-03-11 11:07:11', 'admin', 'menu 编辑 84', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('49', '2016-03-11 11:07:34', 'admin', 'menu 编辑 85', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('50', '2016-03-11 11:09:52', 'admin', 'menu 编辑 86', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('51', '2016-03-11 11:09:57', 'admin', 'Menu 删除 14', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('52', '2016-03-11 11:10:01', 'admin', 'Menu 删除 104', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('53', '2016-03-11 11:10:16', 'admin', 'menu 编辑 88', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('54', '2016-03-11 11:10:27', 'admin', 'menu 编辑 88', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('55', '2016-03-11 11:10:42', 'admin', 'menu 编辑 89', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('56', '2016-03-11 11:10:51', 'admin', 'Menu 删除 90', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('57', '2016-03-11 11:10:55', 'admin', 'Menu 删除 91', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('58', '2016-03-11 11:11:09', 'admin', 'Menu 删除 94', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('59', '2016-03-11 11:11:13', 'admin', 'Menu 删除 93', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('60', '2016-03-11 11:11:15', 'admin', 'Menu 删除 92', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('61', '2016-03-11 11:12:24', 'admin', 'menu 新增 108', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('62', '2016-03-11 11:12:32', 'admin', 'menu 编辑 108', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('63', '2016-03-11 11:16:27', 'admin', 'menu 编辑 95', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('64', '2016-03-11 11:18:21', 'admin', 'menu 新增 109', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('65', '2016-03-11 11:18:28', 'admin', 'menu 编辑 81', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('66', '2016-03-11 11:18:36', 'admin', 'menu 编辑 82', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('67', '2016-03-11 11:22:07', 'admin', 'menu 新增 110', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('68', '2016-03-11 11:22:21', 'admin', 'menu 新增 111', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Menu/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('69', '2016-03-11 11:31:22', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.2.7 (KHTML, like Gecko) Version/9.0.', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('70', '2016-03-11 11:33:21', 'admin', 'rule 新增 1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('71', '2016-03-11 11:33:56', 'admin', 'rule 新增 2', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('72', '2016-03-11 11:34:13', 'admin', 'rule 新增 3', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('73', '2016-03-11 11:39:37', 'admin', 'rule 新增 4', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('74', '2016-03-11 11:40:00', 'admin', 'rule 新增 5', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('75', '2016-03-11 11:40:20', 'admin', 'rule 新增 6', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('76', '2016-03-11 11:40:37', 'admin', 'rule 新增 7', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('77', '2016-03-11 11:40:58', 'admin', 'rule 新增 8', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('78', '2016-03-11 11:41:20', 'admin', 'rule 新增 9', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('79', '2016-03-11 11:41:29', 'admin', 'rule 编辑 9', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('80', '2016-03-11 11:41:48', 'admin', 'rule 新增 10', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('81', '2016-03-11 11:42:06', 'admin', 'rule 新增 11', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('82', '2016-03-11 11:42:15', 'admin', 'rule 编辑 11', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('83', '2016-03-11 11:44:31', 'admin', 'rule 新增 12', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('84', '2016-03-11 11:44:55', 'admin', 'rule 编辑 10', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('85', '2016-03-11 11:45:15', 'admin', 'rule 新增 13', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('86', '2016-03-11 11:45:49', 'admin', 'menu 编辑 103', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.2.7 (KHTML, like Gecko) Version/9.0.', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('87', '2016-03-11 11:46:32', 'admin', 'rule 新增 14', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('88', '2016-03-11 11:46:51', 'admin', 'rule 新增 15', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('89', '2016-03-11 11:47:11', 'admin', 'rule 新增 16', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('90', '2016-03-11 11:47:28', 'admin', 'rule 新增 17', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('91', '2016-03-11 11:48:01', 'admin', 'rule 新增 18', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('92', '2016-03-11 11:48:09', 'admin', 'rule 编辑 5', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('93', '2016-03-11 11:48:18', 'admin', 'rule 编辑 1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('94', '2016-03-11 11:48:45', 'admin', 'rule 新增 19', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('95', '2016-03-11 11:49:24', 'admin', 'rule 新增 20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('96', '2016-03-11 11:49:54', 'admin', 'rule 新增 21', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('97', '2016-03-11 11:50:20', 'admin', 'rule 新增 22', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('98', '2016-03-11 11:50:44', 'admin', 'rule 新增 23', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('99', '2016-03-11 11:51:12', 'admin', 'rule 新增 24', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('100', '2016-03-11 11:51:17', 'admin', 'rule 编辑 24', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('101', '2016-03-11 11:52:20', 'admin', 'rule 新增 25', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('102', '2016-03-11 11:53:40', 'admin', 'rule 新增 26', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('103', '2016-03-11 11:54:19', 'admin', 'rule 新增 27', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('104', '2016-03-11 11:54:27', 'admin', 'rule 编辑 27', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('105', '2016-03-11 11:54:40', 'admin', 'rule 新增 28', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('106', '2016-03-11 11:54:58', 'admin', 'rule 新增 29', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('107', '2016-03-11 11:55:16', 'admin', 'rule 新增 30', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('108', '2016-03-11 11:55:38', 'admin', 'rule 新增 31', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('109', '2016-03-11 11:55:54', 'admin', 'rule 新增 32', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('110', '2016-03-11 11:56:19', 'admin', 'rule 新增 33', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('111', '2016-03-11 11:56:51', 'admin', 'rule 新增 34', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('112', '2016-03-11 11:56:57', 'admin', 'rule 编辑 23', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('113', '2016-03-11 11:57:24', 'admin', 'menu 编辑 24', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.2.7 (KHTML, like Gecko) Version/9.0.', '/admin.php/Home/Menu/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('114', '2016-03-11 11:57:32', 'admin', 'rule 新增 35', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('115', '2016-03-11 11:57:42', 'admin', 'rule 编辑 34', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('116', '2016-03-11 11:58:13', 'admin', 'rule 新增 36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('117', '2016-03-11 11:58:33', 'admin', 'rule 新增 37', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('118', '2016-03-11 11:58:58', 'admin', 'rule 新增 38', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('119', '2016-03-11 12:05:27', 'admin', '退出成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/logout.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('120', '2016-03-11 12:05:42', 'admin', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('121', '2016-03-11 14:39:54', 'admin', 'dep 新增 33', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Dep/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('122', '2016-03-11 14:40:05', 'admin', 'dep 新增 34', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Dep/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('123', '2016-03-11 14:41:03', 'admin', 'rule 新增 39', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('124', '2016-03-11 14:41:22', 'admin', 'rule 新增 40', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('125', '2016-03-11 14:41:37', 'admin', 'rule 新增 41', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Rule/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('126', '2016-03-11 14:42:55', 'admin', 'dep 新增 35', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Dep/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('127', '2016-03-11 14:42:59', 'admin', 'dep 编辑 35', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Dep/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('128', '2016-03-11 14:43:06', 'admin', 'Dep 删除 35', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Dep/del.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('129', '2016-03-11 14:43:21', 'admin', 'user 新增 0', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/add.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('130', '2016-03-11 14:59:25', 'admin', 'user 编辑 1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('131', '2016-03-11 15:03:20', 'admin', 'user 编辑 1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('132', '2016-03-11 15:04:28', 'admin', 'user 编辑 1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('133', '2016-03-11 17:37:48', 'admin', 'user 编辑 1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('134', '2016-03-11 17:38:30', 'admin', 'user 编辑 1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('135', '2016-03-11 17:38:42', 'admin', 'user 编辑 1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('136', '2016-03-11 17:39:54', 'admin', 'user 编辑 11', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/edit.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('137', '2016-03-11 17:42:36', '', '退出成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.2.7 (KHTML, like Gecko) Version/9.0.', '/admin.php/Home/Public/logout.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('138', '2016-03-11 17:42:40', '123', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.2.7 (KHTML, like Gecko) Version/9.0.', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('139', '2016-03-11 17:44:13', '123', '退出成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.2.7 (KHTML, like Gecko) Version/9.0.', '/admin.php/Home/Public/logout.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('140', '2016-03-11 17:45:18', 'admin', 'User锁定11', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/status.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('141', '2016-03-11 17:46:39', 'admin', 'User启用11', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/User/status.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('142', '2016-03-11 17:46:42', '123', '登录成功！', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.2.7 (KHTML, like Gecko) Version/9.0.', '/admin.php/Home/Public/Login.html', '0.0.0.0');
INSERT INTO `llhl_log` VALUES ('143', '2016-03-11 17:47:35', 'admin', '权限设置成功', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2', '/admin.php/Home/Dep/EditRule.html', '0.0.0.0');

-- -----------------------------
-- Table structure for `llhl_menu`
-- -----------------------------
DROP TABLE IF EXISTS `llhl_menu`;
;

-- -----------------------------
-- Records of `llhl_menu`
-- -----------------------------
INSERT INTO `llhl_menu` VALUES ('7', '0', '0', '系统管理', 'system/index', '8', '1', 'fa-cogs', 'system');
INSERT INTO `llhl_menu` VALUES ('11', '2', '22', '菜单管理', 'menu/index', '4', '1', 'fa-caret-right', 'menu');
INSERT INTO `llhl_menu` VALUES ('21', '2', '74', '备份管理', 'database/bakup', '2', '1', 'fa-caret-right', 'databases_bakup');
INSERT INTO `llhl_menu` VALUES ('19', '2', '22', '功能列表', 'rule/index', '5', '1', 'fa-caret-right', 'rule');
INSERT INTO `llhl_menu` VALUES ('22', '1', '7', '系统设置', 'system/index/', '4', '1', 'fa-caret-right', 'system');
INSERT INTO `llhl_menu` VALUES ('24', '2', '74', '数据库优化', 'database/index', '1', '1', 'fa-caret-right', 'databasesbackup');
INSERT INTO `llhl_menu` VALUES ('31', '2', '22', '数据字典', 'config/index', '1', '1', 'fa-caret-right', 'config');
INSERT INTO `llhl_menu` VALUES ('74', '1', '7', '数据库管理', 'database/index', '3', '1', 'fa-caret-right', 'databases');
INSERT INTO `llhl_menu` VALUES ('107', '1', '81', '提现设置', 'moneyoffer/set', '3', '1', 'fa-caret-right', 'moneyoffer');
INSERT INTO `llhl_menu` VALUES ('81', '0', '0', '会员管理', 'fans/index/', '1', '1', 'fa-users', 'fans');
INSERT INTO `llhl_menu` VALUES ('82', '1', '81', '会员列表', 'fans/index', '1', '1', 'fa-caret-right', 'fans');
INSERT INTO `llhl_menu` VALUES ('83', '1', '81', '提现申请管理', 'moneyoffer/index', '2', '1', 'fa-caret-right', 'moneyoffer');
INSERT INTO `llhl_menu` VALUES ('84', '0', '0', '订单管理', 'order/index', '2', '1', 'fa-sitemap', 'order');
INSERT INTO `llhl_menu` VALUES ('85', '1', '84', '订单列表', 'order/index', '1', '1', 'fa-caret-right', 'order');
INSERT INTO `llhl_menu` VALUES ('86', '1', '84', '分成管理', 'affiliate/index', '2', '1', 'fa-caret-right', 'affiliate');
INSERT INTO `llhl_menu` VALUES ('88', '0', '0', '流量套餐管理', 'goods/index', '3', '1', 'fa-gift', 'goods');
INSERT INTO `llhl_menu` VALUES ('89', '1', '88', '套餐列表', 'goods/index', '1', '1', 'fa-caret-right', 'goods');
INSERT INTO `llhl_menu` VALUES ('111', '1', '109', '角色管理', 'dep/index', '2', '1', 'fa-caret-right', 'dep');
INSERT INTO `llhl_menu` VALUES ('108', '1', '95', '微信支付参数', 'wechat/pay', '5', '1', 'fa-caret-right', 'wechat_pay');
INSERT INTO `llhl_menu` VALUES ('109', '0', '0', '后台用户管理', 'user/index', '5', '1', 'fa-user-secret', 'user');
INSERT INTO `llhl_menu` VALUES ('110', '1', '109', '用户列表', 'user/index', '1', '1', 'fa-caret-right', 'user');
INSERT INTO `llhl_menu` VALUES ('95', '0', '0', '微信平台管理', 'wechat/index', '4', '1', 'fa-weixin', 'wechat');
INSERT INTO `llhl_menu` VALUES ('96', '1', '95', '微信接口参数设置', 'wechat/index', '1', '1', 'fa-caret-right', 'wechat_config');
INSERT INTO `llhl_menu` VALUES ('97', '1', '95', '用户关注回复', 'wechat/subscribe', '2', '1', 'fa-caret-right', 'wechat_subscribe');
INSERT INTO `llhl_menu` VALUES ('98', '1', '95', '自定义菜单', 'wechat/menu', '3', '1', 'fa-caret-right', 'wechat_menu');
INSERT INTO `llhl_menu` VALUES ('99', '1', '95', '关键字回复', 'wechat/keyword', '4', '1', 'fa-caret-right', 'wechat_keyword');
INSERT INTO `llhl_menu` VALUES ('100', '0', '0', '日志管理', 'log/index', '7', '1', 'fa-book', 'log');
INSERT INTO `llhl_menu` VALUES ('101', '1', '100', '系统操作日志', 'log/index', '1', '1', 'fa-caret-right', 'log');
INSERT INTO `llhl_menu` VALUES ('102', '1', '100', '短信日志', 'sms/log', '2', '1', 'fa-caret-right', 'smslog');
INSERT INTO `llhl_menu` VALUES ('103', '1', '7', '短信接口设置', 'sms/config', '1', '1', 'fa-caret-right', 'smsapi');

-- -----------------------------
-- Table structure for `llhl_sms_log`
-- -----------------------------
DROP TABLE IF EXISTS `llhl_sms_log`;
;


-- -----------------------------
-- Table structure for `llhl_user`
-- -----------------------------
DROP TABLE IF EXISTS `llhl_user`;
;

-- -----------------------------
-- Records of `llhl_user`
-- -----------------------------
INSERT INTO `llhl_user` VALUES ('1', 'admin', '14e1b600b1fd579f47433b88e8d85291', '74870e1114ddb042052b11710f2e1316', '33', '毛腾飞', '男', '13598835763', 'pinkecn@qq.com', '2016-03-11 12:05:42', '0.0.0.0', '479', '1', '1457689655');
INSERT INTO `llhl_user` VALUES ('11', '123', 'd9b1d7db4cd6e70935368a1efb10e377', '', '34', '123', '女', '123', '', '2016-03-11 17:46:42', '0.0.0.0', '', '1', '1457689602');

-- -----------------------------
-- Table structure for `mobile_belong`
-- -----------------------------
DROP TABLE IF EXISTS `mobile_belong`;
;

-- -----------------------------
-- Records of `mobile_belong`
-- -----------------------------
INSERT INTO `mobile_belong` VALUES ('1', '1300000', 'É½¶«', '¼ÃÄÏ', 'ÖÐ¹úÁªÍ¨', '0531', '250000');

-- -----------------------------
-- Table structure for `order`
-- -----------------------------
DROP TABLE IF EXISTS `order`;
;


-- -----------------------------
-- Table structure for `recharge`
-- -----------------------------
DROP TABLE IF EXISTS `recharge`;
;


-- -----------------------------
-- Table structure for `users`
-- -----------------------------
DROP TABLE IF EXISTS `users`;
;


-- -----------------------------
-- Table structure for `users_account_log`
-- -----------------------------
DROP TABLE IF EXISTS `users_account_log`;
;


-- -----------------------------
-- Table structure for `users_bank`
-- -----------------------------
DROP TABLE IF EXISTS `users_bank`;
;


-- -----------------------------
-- Table structure for `users_money_offer`
-- -----------------------------
DROP TABLE IF EXISTS `users_money_offer`;
;


-- -----------------------------
-- Table structure for `wechat_config`
-- -----------------------------
DROP TABLE IF EXISTS `wechat_config`;
;


-- -----------------------------
-- Table structure for `wechat_keyword_reply`
-- -----------------------------
DROP TABLE IF EXISTS `wechat_keyword_reply`;
;


-- -----------------------------
-- Table structure for `wechat_menu`
-- -----------------------------
DROP TABLE IF EXISTS `wechat_menu`;
;


-- -----------------------------
-- Table structure for `wechat_subscribe_reply`
-- -----------------------------
DROP TABLE IF EXISTS `wechat_subscribe_reply`;
;

